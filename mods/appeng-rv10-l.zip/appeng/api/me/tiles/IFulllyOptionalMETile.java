package appeng.api.me.tiles;

/**
 * Cables will disconnect if its not enabled.
 */
public interface IFulllyOptionalMETile extends IOptionalMETile {

}

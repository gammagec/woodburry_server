package appeng.api;

import appeng.common.registries.entries.AppEngHandler;

public interface IItemComparison {
	
	public boolean sameAsPrecise( IItemComparison comp);

	public boolean sameAsFuzzy(IItemComparison comp);	
	
}
